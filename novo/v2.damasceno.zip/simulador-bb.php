<?php include("header.php");?>
	<!-- BEGIN BB FRAME -->
	  <iframe src ="https://www42.bb.com.br/portalbb/creditoImobiliario/Proposta,2,2250,2250.bbx" width="100%" height="800"></iframe>
	<!-- END BB FRAME -->
<?php include("footer.php");?>	