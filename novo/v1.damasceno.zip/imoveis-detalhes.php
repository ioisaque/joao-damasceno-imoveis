<?php include("header.php");?>
	<!-- BEGIN PAGE TITLE/BREADCRUMB -->
	<div class="parallax colored-bg pattern-bg" data-stellar-background-ratio="0.5">
		<div class="container">
			<div class="row">
				<div class="col-sm-12">
					<h1 class="page-title"><?php echo lang('DETALHES_DO_IMOVEL'); ?></h1>
					
					<ul class="breadcrumb">
						<li><a href="index.php"><?php echo lang('INICIO'); ?> </a></li>
						<li><a href="imoveis.php"><?php echo lang('IMOVEIS'); ?></a></li>
						<li><a href="imoveis-detalhes.php"><?php echo lang('DETALHES'); ?></a></li>
					</ul>
				</div>
			</div>
		</div>
	</div>
	<!-- END PAGE TITLE/BREADCRUMB -->
	
	
	<!-- BEGIN CONTENT WRAPPER -->
	<div class="content">
		<div class="container">
			<div class="row">			
			  <?php $imovel = $imoveis->getImovelByID( get('id_imovel') ); ?>
			  <?php if($imovel): ?>		
				<!-- BEGIN MAIN CONTENT -->
				<div class="main col-sm-8">
				
					<h1 class="property-title"><?php echo $imovel->titulo; ?></h1>

					<!-- BEGIN PROPERTY DETAIL SLIDERS WRAPPER -->
					<div id="property-detail-wrapper" class="style1">
						
						<div class="price">
							<i class="fa fa-home"></i><?php echo $imovel->operacao; ?>
							<span><?php echo moeda($imovel->valor); ?></span>
						</div>
								
						<!-- BEGIN PROPERTY DETAIL LARGE IMAGE SLIDER -->
						<?php $imagens = $imoveis->getImovelIMGs($imovel->id); ?>
						  <?php if($imagens): ?>
						  
							<div id="property-detail-large" class="owl-carousel">
							  <?php foreach($imagens as $img): ?>							
								<div class="item">
									<img src="images/uploads/<?php echo $img->nome; ?>" alt="" height="760" />
								</div>
							  <?php endforeach; ?>

							</div>
						<!-- END PROPERTY DETAIL LARGE IMAGE SLIDER -->
						
								<!-- BEGIN PROPERTY DETAIL THUMBNAILS SLIDER -->
								<div id="property-detail-thumbs" class="owl-carousel">
								  <?php foreach($imagens as $img): ?>							
									<div class="item">
										<img src="images/uploads/<?php echo $img->nome; ?>" alt="" />
									</div>
								  <?php endforeach; ?>
								</div>
								<!-- END PROPERTY DETAIL THUMBNAILS SLIDER -->
						
						  <?php endif; ?>						  
					</div>
					
					<?php echo cleanOut($imovel->descricao); ?>
					<p>&nbsp;</p>
					
					
					<!-- BEGIN PROPERTY AMENITIES LIST 
					<ul class="property-amenities-list col-md-4">
						<li class="enabled"> Suítes </li>
						<li class="enabled"> Guarda-Roupas </li>
						<li class="enabled"> Armários na Cozinha </li>
					</ul>
					
					<ul class="property-amenities-list col-md-4">
						<li class="enabled"> Piscina </li>
						<li class="disabled"> Garagem </li>
						<li class="enabled"> Portão Eletrônico </li>
					</ul>
					
					<ul class="property-amenities-list col-md-4">
						<li class="enabled"> Elevador </li>
						<li class="enabled"> Churrasqueira </li>
					</ul>
					 END PROPERTY AMENITIES LIST -->
					 
					
					<!-- BEGIN PROPERTY FEATURES LIST -->
					<h1 class="section-title"><?php echo lang('CARACTERISTICAS'); ?></h1>
					
					<?php if ($imovel->garagem > 0): ?>
					  <ul class="property-features col-sm-6">
						<li><i class="icon-garage"></i> <?php echo $imovel->garagem .' '. lang('GARAGEM') .'(s)'; ?></li>
					  </ul>					
					<?php endif; ?>
					<?php if ($imovel->piscina == 1): ?>
					  <ul class="property-features col-sm-6">
						<li><i class="icon-pool"></i> <?php echo lang('PISCINA'); ?></li>
					  </ul>					
					<?php endif; ?>
					<?php if ($imovel->suites > 0 AND $imovel->quartos > 0) { ?>
					  <ul class="property-features col-sm-6">
						<li><i class="icon-rooms"></i> <?php echo $imovel->suites .' '. lang('SUITE') .'(s) e '. $imovel->quartos .' '. lang('QUARTO') .'(s)'; ?></li>
					  </ul>
					<?php } else {  ?>
					<?php if ($imovel->suites > 0): ?>					  
					  <ul class="property-features col-sm-6">
						<li><i class="icon-rooms"></i> <?php echo $imovel->suites .' '. lang('SUITE') .'(s)'; ?></li>
					  </ul>
					<?php endif; ?>					
					<?php if ($imovel->quartos > 0): ?>					  
					  <ul class="property-features col-sm-6">
						<li><i class="icon-bedrooms"></i> <?php echo $imovel->quartos .' '. lang('QUARTO') .'(s)'; ?></li>
					  </ul>
					<?php endif; } ?>
					<?php if ($imovel->banheiros > 0): ?>					  
					  <ul class="property-features col-sm-6">
						<li><i class="icon-bathrooms"></i> <?php echo $imovel->banheiros .' '. lang('BANHEIRO') .'(s)'; ?></li>
					  </ul>
					<?php endif; ?>
					<?php if ($imovel->portao == 1): ?>					  
					  <ul class="property-features col-sm-6">
						<li><i class="icon-security"></i> <?php echo lang('PORTAO'); ?></li>
					  </ul>
					<?php endif; ?>
					<?php if ($imovel->elevador == 1): ?>					  
					  <ul class="property-features col-sm-6">
						<li><i class="icon-apartment"></i> <?php echo lang('ELEVADOR'); ?></li>
					  </ul>
					<?php endif; ?>
					<?php if ($imovel->churrasqueira == 1): ?>
					  <ul class="property-features col-sm-6">
						<li><i class="icon-land"></i> <?php echo lang('CHURRASQUEIRA'); ?></li>
					  </ul>
					<?php endif; ?>		
					<?php if ($imovel->armario == 1): ?>
					  <ul class="property-features col-sm-6">
						<li><i class="icon-area"></i> <?php echo lang('ARMARIO'); ?></li>
					  </ul>
					<?php endif; ?>
					<?php if ($imovel->guardaroupa == 1): ?>
					  <ul class="property-features col-sm-6">
						<li><i class="icon-find-agent"></i> <?php echo lang('GUARDA_ROUPA'); ?></li>
					  </ul>
					<?php endif; ?>	
					<!-- END PROPERTY FEATURES LIST -->
					
			  <?php endif; ?>					
					
				<!-- BEGIN SIMILAR PROPERTIES -->
				  <?php $items = $imoveis->getSimilarImoveis($imovel->id, $imovel->bairro); ?>
				  <?php if($items): ?>					
					
					<h1 class="section-title"><?php echo lang('IMOVEIS_SIMILARES'); ?></h1>
					
					<div id="similar-properties" class="grid-style1 clearfix">
					  <?php $i =0; ?>		  
						<div class="row">
					  <?php foreach($items as $item): ?>						
							<div class="item col-md-4">
								<div class="image">
									<a href="imoveis-detalhes.php?id_imovel=<?php echo $item->id;?>" class="info">
										<h3><?php echo $item->bairro;?></h3>
										<span class="location"><?php echo $item->cidade;?></span>
									</a>
									<img src="<?php echo $imoveis->getImovelFeaturedIMG($item->id);?>" alt="" height="230"/>
								</div>
								<div class="price">
									<i class="fa fa-home"></i><?php echo $item->operacao;?>
									<span><?php echo moeda($item->valor);?></span>
								</div>
								<ul class="amenities">
									<li><i class="icon-garage"></i> <?php echo $item->garagem;?></li>
									<li><i class="icon-bedrooms"></i> <?php echo $item->quartos;?></li>
									<li><i class="icon-bathrooms"></i> <?php echo $item->banheiros;?></li>
								</ul>
							</div>
						<?php  $i++; if ( $i == 3 ): $i =0;  ?>
						</div><!-- end of Property Set -->		  
						<div class="row">
						<?php endif;?>						
					  <?php endforeach;?>		
						</div><!-- end of Property Set -->				
						
					<p class="center">
						<a href="imoveis.php?inputLocalizacao=<?php echo $imovel->bairro;?>" class="btn btn-default-color">Ver Mais</a>
					</p>
					<!-- END PROPERTIES ASSIGNED -->						
						
				  <?php endif;?>
					
				</div>	
				<!-- END MAIN CONTENT -->
				
				<?php //include("sidebar.php");?>

			</div>
		</div>
	</div>
	<!-- END CONTENT WRAPPER -->		
<?php include("footer.php");?>	