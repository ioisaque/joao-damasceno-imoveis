<?php include("header.php");?>
		
	<!-- BEGIN HOME GRID -->
	<div id="home-grid">
		<div id="freewall" class="free-wall">
		  <?php $items = $imoveis->getIndexGridImoveis(); ?>
		  <?php if($items): ?>
		  <?php foreach($items as $item): ?>		  
			<div class="item">
				<a class="info" href="imoveis-detalhes.php?id_imovel=<?php echo $item->id;?>">
					<span class="price">
						<i class="fa fa-home"></i><?php echo $item->operacao;?><span><?php echo moeda($item->valor);?></span>
					</span>
					<h3><?php echo $item->titulo;?></h3>
					<span class="location"><?php echo $item->cidade;?></span>
				</a>
				<img src="<?php echo $imoveis->getImovelFeaturedIMG($item->id);?>" alt="" />
			</div>
		  <?php endforeach;?>					
		  <?php endif;?>				
		</div>
	</div>
	<!-- END HOME GRID -->
	
	<?php include("pesquisa_avancada.php");?>
	
	<div class="home3-hero">
		<div class="container">
			<div class="row">
				<div class="col-sm-12">
					<center><h2 data-animation-direction="from-center" data-animation-delay="100">Nós trabalhamos para fazer parte de<br/>conquistas importantes da sua vida.</h2></center>
					<center><p data-animation-direction="from-left" data-animation-delay="300">Por isso, oferecemos mais do que tradição e experiência no mercado imobiliário: oferecemos soluções reais que facilitam o dia-a-dia de nossos clientes. <br/>Isso se traduz em tranqüilidade e na certeza de satisfazer as expectativas de todos os clientes.</p></center>
					<!--<a href="agent-listing.html" class="btn btn-default-color" data-animation-direction="from-left" data-animation-delay="500">Encontre a sua casa!</a>-->
				</div>
			</div>
		</div>
	</div>
	
	<!-- BEGIN PROPERTIES SLIDER WRAPPER-->
	<div class="parallax dark-bg" id="home-grid-latest-properties" data-stellar-background-ratio="0.5">
		<div class="container">
			<div class="row">
				<div class="col-sm-12">
					<h1 class="section-title" data-animation-direction="from-bottom" data-animation-delay="50"><?php echo lang('ADICIONADO_RECENTEMENTE'); ?></h1>
					
					<div id="new-properties-slider" class="owl-carousel carousel-style1">
						
					  <?php $items = $imoveis->getDestaqueImoveis(); ?>
					  <?php if($items): ?>
					  <?php foreach($items as $item): ?>							
						<div class="item" data-animation-direction="from-bottom" data-animation-delay="250">
							<div class="image">
								<a href="imoveis-detalhes.php?id_imovel=<?php echo $item->id;?>" class="info">
									<h3><?php echo $item->bairro;?></h3>
									<span class="location"><?php echo $item->cidade;?></span>
								</a>
								<img src="<?php echo $imoveis->getImovelFeaturedIMG($item->id);?>" alt="" height="760"/>
							</div>
							<div class="price">
								<i class="fa fa-home"></i><?php echo $item->operacao;?>
								<span><?php echo moeda($item->valor);?></span>
							</div>
							<ul class="amenities">
								<li><i class="icon-garage"></i> <?php echo $item->garagem;?></li>
								<li><i class="icon-bedrooms"></i> <?php echo $item->quartos;?></li>
								<li><i class="icon-bathrooms"></i> <?php echo $item->banheiros;?></li>
							</ul>
						</div>
					  <?php endforeach;?>
					  <?php endif;?>
					  
					</div>
					
				</div>
			</div>
		</div>
	</div>
	<!-- END PROPERTIES SLIDER WRAPPER -->	
	
	<!-- BEGIN NEWSLETTER WRAPPER WITH COLORED BACKGROUND-->
	<div class="parallax colored-bg" style="background-image:url(images/upper_views/ipatinga.jpg);" data-stellar-background-ratio="0.1">
		<div class="container">
			<div class="row">
				<!-- BEGIN NEWSLETTER -->
				<div id="newsletter" class="col-md-7 center">
					<h1 data-animation-direction="from-top" data-animation-delay="50">Realize o seu <strong>Sonho!</strong></h1>
					<!--<p data-animation-direction="from-top" data-animation-delay="50">com a nossa ajuda...</p>-->
					
					<div class="input-group col-md-7 center" data-animation-direction="from-bottom" data-animation-delay="50">
						<input type="text" placeholder="Seu e-mail" name="newsletter_email" id="newsletter_email" class="form-control" />
						<span class="input-group-btn">
							<button class="btn btn-default" type="button"><?php echo lang('CONTATO'); ?></button>
						</span>
					</div>
				</div>
				<!-- END NEWSLETTER -->
			</div>
		</div>
	</div>
	<!-- END NEWSLETTER WRAPPER WITH COLORED BACKGROUND-->		
<?php include("footer.php");?>		