<?php include("header.php");?>
	<!-- BEGIN CAIXA FRAME -->
	  <iframe src ="http://www8.caixa.gov.br/siopiinternet/simulaOperacaoInternet.do?method=inicializarCasoUso&isVoltar=true" width="100%" height="700"></iframe>
	<!-- END CAIXA FRAME -->
<?php include("footer.php");?>	